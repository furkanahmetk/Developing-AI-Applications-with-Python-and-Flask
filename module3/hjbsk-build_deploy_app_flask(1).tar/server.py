from flask import Flask, render_template, request, jsonify
import Maths

app = Flask("Mathematics Problem Solver")

def parse_float(value):
    """Try to convert input to float, return None if invalid."""
    try:
        return float(value)
    except (ValueError, TypeError):
        return None

@app.route("/sum")
def sum_route():
    num1 = parse_float(request.args.get('num1'))
    num2 = parse_float(request.args.get('num2'))

    if num1 is None or num2 is None:
        return jsonify({"error": "Invalid input. Please enter numbers only."}), 400

    result = Maths.summation(num1, num2)
    return jsonify({"result": int(result) if result.is_integer() else result})

@app.route("/sub")
def sub_route():
    num1 = parse_float(request.args.get('num1'))
    num2 = parse_float(request.args.get('num2'))

    if num1 is None or num2 is None:
        return jsonify({"error": "Invalid input. Please enter numbers only."}), 400

    result = Maths.substraction(num1, num2)
    return jsonify({"result": int(result) if result.is_integer() else result})

@app.route("/mul")
def mul_route():
    num1 = parse_float(request.args.get('num1'))
    num2 = parse_float(request.args.get('num2'))

    if num1 is None or num2 is None:
        return jsonify({"error": "Invalid input. Please enter numbers only."}), 400

    result = Maths.multiplication(num1, num2)
    return jsonify({"result": int(result) if result.is_integer() else result})

@app.route("/")
def render_index_page():
    return render_template('index.html')

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8080)
