def summation(a, b):
    return (a + b)

def substraction(a, b):
    return (a-b)

def multiplication(a, b):
    return (a*b)