import requests 
import json

def sentiment_analyzer(text_to_analyse):
    url = 'https://sn-watson-sentiment-bert.labs.skills.network/v1/watson.runtime.nlp.v1/NlpService/SentimentPredict'
    header = {"grpc-metadata-mm-model-id": "sentiment_aggregated-bert-workflow_lang_multi_stock"}
    my_obj = { "raw_document": { "text": text_to_analyse } }
    response = requests.post(url, json = my_obj, headers=header)
    f_response = json.loads(response.text)

    # If the response status code is 200, extract the label and score from the response
    if response.status_code == 200:
        label = f_response['documentSentiment']['label']
        score = f_response['documentSentiment']['score']
    # If the response status code is 500, set label and score to None
        
    elif response.status_code == 500:
        label = None
        score = None
    # Return the label and score in a dictionary
    return {'label': label, 'score': score}