import requests
import json

def emotion_detector(text_to_analyze):
    """
    Sends a POST request to the Watson NLP EmotionPredict API,
    parses the response, and extracts emotion scores.

    Args:
        text_to_analyze (str): The text to analyze for emotions.

    Returns:
        dict: A dictionary with emotion scores and the dominant emotion.
    """
    url = ('https://sn-watson-emotion.labs.skills.network/v1/watson.runtime.nlp.v1/NlpService/EmotionPredict')
    
    headers = {"grpc-metadata-mm-model-id": "emotion_aggregated-workflow_lang_en_stock"}

    input_json = { "raw_document": { "text": text_to_analyze } }

    response = requests.post(url, headers=headers, json=input_json)

    if response.status_code == 400:
        return {
            "anger": None,
            "disgust": None,
            "fear": None,
            "joy": None,
            "sadness": None,
            "dominant_emotion": None
        }

    if response.status_code != 200:
        return {"error": "Request failed", "status_code": response.status_code}

    result = json.loads(response.text)


    try:
        scores = result["emotionPredictions"][0]["emotion"]

        emotion_scores = {
            "anger": scores.get("anger"),
            "disgust": scores.get("disgust"),
            "fear": scores.get("fear"),
            "joy": scores.get("joy"),
            "sadness": scores.get("sadness")
        }

        dominant_emotion = max(emotion_scores, key=emotion_scores.get)
        emotion_scores["dominant_emotion"] = dominant_emotion

        return emotion_scores

    except (IndexError, KeyError, TypeError):
        return {
            "anger": None,
            "disgust": None,
            "fear": None,
            "joy": None,
            "sadness": None,
            "dominant_emotion": None
        }