"""
Flask server for the Emotion Detection application.

This app serves a web interface and uses a pre-trained NLP model
to analyze user input and return emotion scores and dominant emotion.
"""

#import required modules
from flask import Flask, request, render_template
from EmotionDetection import emotion_detector

#create a Flask instance for the app
app = Flask(__name__)

@app.route('/')
def home():
    """Render the home page with the text input form."""
    return render_template('index.html')

@app.route('/emotionDetector', methods=['GET'])
def get_emotion():
    """
    Receive text input from the client, run emotion detection, 
    and return a formatted string with emotion scores and dominant emotion.

    Returns:
        str: Formatted emotion detection results or error message.
    """
    text_to_analyze = request.args.get('textToAnalyze')

    if not text_to_analyze:
        return "Invalid text! Please try again!"

    result = emotion_detector(text_to_analyze)

    # If all values are None, treat it as invalid input
    if result.get("dominant_emotion") is None:
        return "Invalid text! Please try again!"

    # Check for error in result
    if "error" in result:
        return "Error: Could not process input text", 500

    formatted_result = (
        f"For the given statement, the system response is "
        f"'anger': {result['anger']}, "
        f"'disgust': {result['disgust']}, "
        f"'fear': {result['fear']}, "
        f"'joy': {result['joy']} and "
        f"'sadness': {result['sadness']}. "
        f"The dominant emotion is {result['dominant_emotion']}."
    )

    return formatted_result

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug = True)
