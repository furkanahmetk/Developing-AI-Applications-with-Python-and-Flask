import numpy as np

a = np.array([2,4,4])
b = np.array([3,2,1])
c = a + b
print (c)