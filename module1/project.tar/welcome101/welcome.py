message= "Welcome to the world of programming!"
print (message)