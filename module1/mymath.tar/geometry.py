import math

def area_of_rectangle(length, breadth):
    """
    This function returns the area of a rectangle
    given its length and breadth.
    """
    return length * breadth

def area_of_circle(radius):
    """
    This function returns the area of a circle
    given its radius.
    Formula: π * r^2
    """
    return math.pi * (radius ** 2)