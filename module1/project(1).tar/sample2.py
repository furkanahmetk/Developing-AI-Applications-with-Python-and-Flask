"""Define a function named 'add' that takes two arguments, 'number1' and 'number2'.
 The purpose of this function is to add the two numbers and return the result."""
def add(number1, number2):
    """Return the sum of number1 and number2."""
    return number1 + number2


NUM1 = 4  # Constant value
NUM2 = 5  # Second number for addition

TOTAL = add(NUM1, NUM2)

print(f"The sum of {NUM1} and {NUM2} is {TOTAL}")
